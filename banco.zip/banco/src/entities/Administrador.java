package entities;

import java.util.Scanner;

public class Administrador {
	public int id;
	private String nome;
	private String funcao;
	private long telefone;
	private int listaContasBancarias;
	private long cpf;
	private String login;
	private String password;

	public Administrador(String login, String password) {
		this.login = login;
		this.password = password;
	}
	public Administrador(String nome, String funcao, int telefone, double cpf, String login, String password) {
		this.id = Banco.ID++;
		this.nome = nome;
		this.funcao = funcao;
		this.telefone = (long) telefone;
		this.cpf = (long) cpf;
		this.login = login;
		this.setPassword(password);
	}

	public int getId() {
		return id;
	}


	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}

	public double getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = (long) telefone;
	}

	public double getCpf() {
		return cpf;
	}

	public void setCpf(long cpf) {
		this.cpf = cpf;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public float getListaContasBancarias() {
		return listaContasBancarias;
	}

	public void setListaContasBancarias(int listaContasBancarias) {
		this.listaContasBancarias = listaContasBancarias;
	}

	public int menuAdmin() {
		int verifica = 0;
		do {
			System.out.println("*****Menu Admin*****");
			System.out.println("1- Register Client");
			System.out.println("2- Remove Client");
			System.out.println("3- Search Client");
			System.out.println("4- Logout");
			System.out.println("5- Finish application");
			verifica = chooseOption();
		} while (verifica != 4 && verifica != 5);
		if (verifica == 4)
			return 1;
		else
			return 0;
	}

	public int chooseOption() {
		Scanner sc = new Scanner(System.in);
		System.out.println("***Escolha uma opção:***");
		int op = sc.nextInt();
		switch (op) {
		case 1:
			registerClient();
			break;
		case 2:
			removeClient();
			break;
		case 3:
			searchClient();
			break;
		case 4:
			return 4;
		case 5:
			System.out.println("Aplicação encerrada");
			return 5;
		default:
			System.out.println("Incorrect Option");
			break;
		}
		//sc.close();
		return 1; // volta pro menu
	}
	public Client validarContaClient() {
		for (Client c : Banco.listaCliente) {
			return c;
		}
		return null;
	}

	private void searchClient() {
		int sch;
		Client validarClient = validarContaClient();
		if(validarClient  == null) {
			System.out.println("Não há clientes");
		}else {
			Scanner sc = new Scanner(System.in);
			do {			
				System.out.println("Buscar por CPF - 1");
				System.out.println("Buscar por  ID - 2");
				System.out.println("Buscar por  NOME - 3");
				System.out.println("Voltar pro menu anterior- 0");
				System.out.println("Escolha a forma de buscar:");
				sch = sc.nextInt();
				Client c = null;
				if (sch == 1) {
					long cpf;
					System.out.println("Digite o cpf do cliente:");
					cpf = sc.nextLong();
					c = Banco.buscarPorCpf(cpf);
					if(c == null) {
						System.out.println("Cliente não encontrado");
					}else {
						c.mostrarInfo();
					}
				} else if (sch == 2) {
					int id;
					System.out.println("Digite o id do cliente:");
					id = sc.nextInt();
					sc.nextLine();
					c = Banco.buscarPorId(id);
					if(c == null) {
						System.out.println("Cliente não encontrado");
					}else {
						c.mostrarInfo();
					}
				}else if (sch == 3) {
					String nome;
					System.out.println("Digite o nome do cliente:");
					sc.nextLine();
					nome = sc.nextLine();
					System.out.println(nome);
					c = Banco.buscarPorNome(nome);
					if(c == null) {
						System.out.println("Cliente não encontrado");
					}else {
						c.mostrarInfo();
					}
				}else if (sch == 0){
					System.out.println("Encaminhando para tela anterior");
					break;
				}else {
					System.out.println("Não encontrado");
				}
			}while(sch != 0);	
		}
	}
	
	private void removeClient() {
		Scanner sc = new Scanner(System.in);
		int rmv;
		Client validarClient = validarContaClient();
		if(validarClient  == null) {
			System.out.println("Não há clientes");
		}else {			
			do {			
				System.out.println("Remover por CPF - 1");
				System.out.println("Remover por ID - 2");
				System.out.println("Voltar pro menu anterior- 0");
				System.out.println("Escolha a forma de remover:");
				rmv = sc.nextInt();
				if (rmv == 1) {
					long cpf;
					System.out.println("Digite o cpf do cliente:");
					cpf = sc.nextLong();
					Banco.removerPorCpf(cpf);
				} else if (rmv == 2) {
					int id;
					System.out.println("Digite o id do cliente:");
					id = sc.nextInt();
					Banco.removerPorId(id);
				}else if(rmv != 0){
					System.out.println("Opção Invalida");
				}
			}while(rmv != 0);
			//sc.close();
		}
	}

	private void registerClient() {
		Scanner sc = new Scanner(System.in);
		String login;
		String password;
		String nome;
		long telefone;
		long cpf;
		System.out.print("Digite o login do cliente: ");
		login = (sc.nextLine());
		System.out.print("Digite a senha do cliente: ");
		password = sc.nextLine();
		System.out.print("Digite o nome do cliente: ");
		nome = sc.nextLine();
		System.out.print("Telefone para contato: ");
		telefone = sc.nextLong();
		System.out.print("CPF do cliente: ");
		cpf = sc.nextLong();
		if (Banco.buscarPorCpf(cpf) != null || Banco.buscarPorLogin(login) != null) {
			System.out.println("Cliente ja cadastrado");
		}else if(login.equals(this.login)) {
			System.out.println("Login Invalido");
		}else {
			System.out.println("Cliente cadastrado");
			Banco.listaCliente.add(new Client(Banco.ID++, login, password, nome, telefone, cpf));
		}
		//sc.close();
	}
	

}
