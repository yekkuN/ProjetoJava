package entities;

import java.util.Scanner;

public class Login {
	String login;
	String password;

	public int logarUsuario() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Digite o login: ");
		login = sc.next();
		sc.nextLine();
		System.out.println("Digite a senha: ");
		password = sc.next();
		sc.nextLine();

		if (login.equals("admin") && password.equals("admin")) {
			Administrador showMenuAdmin = new Administrador(login, password);
			return showMenuAdmin.menuAdmin();
		} else{
			Client c = Banco.validarClient(login, password);
			if(c != null) {
				return c.menuCliente();
			}else {
				System.out.println("Usuario nao encotrado");
				return 1;
			}
		}
	}
}
