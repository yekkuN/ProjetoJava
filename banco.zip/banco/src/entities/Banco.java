package entities;

import java.util.ArrayList;

public class Banco {
	static ArrayList<Client> listaCliente = new ArrayList<Client>();
	public static int ID=0;
	
	public static Client buscarPorCpf(long cpf) {
		for (Client c : Banco.listaCliente) {
			if (c.getCpf() == cpf) {
				return c;
			}

		}
		return null;
	}

	public static Client buscarPorLogin(String login) {
		for (Client c : Banco.listaCliente) {
			if (c.getLogin().equals(login)) {
				return c;
			}
		}
		return null;
	}
	
	public static Client validarLogin(String login, String password) {
		for (Client c : Banco.listaCliente) {
			if (c.getLogin().equals(login) && c.getPassword().equals(password)) {
				return c;
			}
		}
		return null;
	}

	public static Client buscarPorId(int id) {
		for (Client c : Banco.listaCliente) {
			if (c.getId() == id) {
				return c;
			}
		}
		return null;
	}

	public static Client buscarPorNome(String nome) {
		for (Client c : Banco.listaCliente) {
			if (c.getNome().equals(nome)) {
				return c;
			}
		}
		return null;
	}

	public static Client validarClient(String login, String senha) {
		for (Client c : Banco.listaCliente) {
			if (c.getPassword().equals(senha) && c.getLogin().equals(login)) {
				return c;
			}
		}
		
		return null;
	}

	public static Client removerPorCpf(long cpf) {
		for (Client c : Banco.listaCliente) {
			if (c.getCpf() == cpf) {
				Banco.listaCliente.remove(c);
				System.out.println("O cliente foi removido com sucesso");
				return c;
			}
		}
		System.out.println("Cliente não encontrado");
		return null;
	}
	public static Client removerPorId(int id) {
		for (Client c : Banco.listaCliente) {
			if (c.getId() == id) {
				Banco.listaCliente.remove(c);
				System.out.println("O cliente foi removido com sucesso");
				return c;
			}
		}
		System.out.println("Cliente não encontrado");
		return null;
	}
	
}
