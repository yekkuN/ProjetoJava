package entities;

public class ContaCorrente {
	private int numeroConta;
	private int agenciaConta;
	private int senhaConta;
	private double saldoConta;


	public int getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(int numeroConta) {
		this.numeroConta = numeroConta;
	}

	public int getAgenciaConta() {
		return agenciaConta;
	}

	public void setAgenciaConta(int agenciaConta) {
		this.agenciaConta = agenciaConta;
	}

	public int getSenhaConta() {
		return senhaConta;
	}

	public void setSenhaConta(int senhaConta) {
		this.senhaConta = senhaConta;
	}

	public double getSaldoConta() {
		return saldoConta;
	}

	public void setSaldoConta(double saldoConta) {
		this.saldoConta = saldoConta;
	}

	public ContaCorrente(int numeroConta, int agenciaConta, int senhaConta, double saldoConta) {
		this.numeroConta = numeroConta;
		this.agenciaConta = agenciaConta;
		this.senhaConta = senhaConta;
		this.saldoConta = saldoConta;
	}

	public void mostrarContaComSenha() {
		System.out.println("Agencia: " + this.agenciaConta);
		System.out.println("Numero da conta: " + this.numeroConta);
		System.out.println("Senha da conta: " + this.senhaConta);
		System.out.println("****************************************");
	}

	public void mostrarContaSemSaldo() {
		System.out.println("Agencia: " + this.agenciaConta);
		System.out.println("Numero da conta: " + this.numeroConta);
		System.out.println("****************************************");
	}

	public void mostrarSaldo() {
		System.out.println("****************************************");
		System.out.println("Saldo da conta: " + this.saldoConta);
		System.out.println("****************************************");
	}
	
}


