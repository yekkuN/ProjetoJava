package entities;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import application.Center;

public class Client {
	private int id;
	private String login;
	private String password;
	private String nome;
	private long telefone;
	private long cpf;
	private ArrayList<ContaCorrente> listaContasBancarias;
	int chooseOption;

	public int getId() {
		return id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public long getTelefone() {
		return telefone;
	}

	public void setTelefone(long telefone) {
		this.telefone = telefone;
	}

	public long getCpf() {
		return cpf;
	}

	public void setCpf(long cpf) {
		this.cpf = cpf;
	}

	public ArrayList<ContaCorrente> getListaContasBancarias() {
		return this.listaContasBancarias;
	}

	public void setListaContasBancarias(ArrayList<ContaCorrente> listaContasBancarias) {
		this.listaContasBancarias = listaContasBancarias;
	}

	public Client(int id, String login, String password, String nome, long telefone, long cpf) {
		this.id = id;
		this.login = login;
		this.password = password;
		this.nome = nome;
		this.telefone = telefone;
		this.cpf = cpf;
		this.listaContasBancarias = new ArrayList<ContaCorrente>();
	}

	public int menuCliente() {
		int verifica = 0;
		do {
			System.out.println("*****Client Menu*****");
			System.out.println("1- Open Account");
			System.out.println("2- Close Account");
			System.out.println("3 -Check Balance");
			System.out.println("4- Transfer");
			System.out.println("5- Deposit");
			System.out.println("6- Pay the Bill");
			System.out.println("7- View Account");
			System.out.println("8- Logout");
			System.out.println("9- Close the Application");
			System.out.println("Escolha alguma opção:");
			verifica = chooseOption();
		} while (verifica != 8 && verifica != 9);
		if (verifica == 8) {
			return 1;
		} else {
			return 0;
		}
	}

	public int chooseOption() {
		Scanner sc = new Scanner(System.in);
		System.out.println("***Escolha uma opção:***");
		chooseOption = sc.nextInt();
		switch (chooseOption) {
		case 1:
			openAccount();
			break;
		case 2:
			closeAccount();
			break;
		case 3:
			checkBalance();
			break;
		case 4:
			transfer();
			break;
		case 5:
			deposit();
			break;
		case 6:
			payBill();
			break;
		case 7:
			verTodasContas();
			break;
		case 8:
			return 8;
		case 9:
			System.out.println("Aplicação encerrada");
			return 9;
		default:
			System.out.println("Incorrect Option");
			break;
		}
		return 1;
		// sc.close();
	}

	public void mostrarInfo() {
		System.out.println("Id:" + this.id);
		System.out.println("Nome:" + this.nome);
		System.out.println("Cpf:" + this.cpf);
		System.out.println("Telefone:" + this.telefone);
		System.out.println("Login:" + this.login);
		System.out.println("Listas de contas bancarias: ");
		if (this.listaContasBancarias.size() == 0) {
			System.out.println("Sem conta bancaria");
		} else {
			verTodasContas();
		}
	}

	public void openAccount() {
		Random random = new Random();
		Scanner sc = new Scanner(System.in);
		int numeroConta;
		int numeroAgencia;
		int saldoConta;
		int senhaConta;
		numeroConta = random.nextInt(89999) + 10000;
		numeroAgencia = random.nextInt(8999) + 1000;
		senhaConta = random.nextInt(8999) + 1000;
		saldoConta = random.nextInt(100000);
		listaContasBancarias.add(new ContaCorrente(numeroConta, numeroAgencia, senhaConta, saldoConta));
		System.out.println("Conta aberta com sucesso");
	}

	public void checkBalance() {
		Scanner sc = new Scanner(System.in);
		ContaCorrente contaCorrente = viewAccount();
		if (contaCorrente == null) {
			System.out.println("Conta não existe");
		} else {
			int agenciaConta = 0;
			int numeroConta = 0;
			verTodasContas();
			System.out.print("Informe a agencia:");
			agenciaConta = sc.nextInt();
			System.out.print("Informe o numero da conta:");
			numeroConta = sc.nextInt();
			ContaCorrente contaCorrenteClient = validarContaCorrente(agenciaConta, numeroConta);
			if (contaCorrenteClient == null) {
				System.out.println("Conta ou agencia não encontrados");
			} else {
				contaCorrenteClient.mostrarSaldo();
			}
		}

	}

	public void transfer() {
		Scanner sc = new Scanner(System.in);
		ContaCorrente contaCorrente = viewAccount();
		if (contaCorrente == null) {
			System.out.println("Conta não existe");
		} else {
			int agenciaConta = 0;
			int numeroConta = 0;
			String nomeCliente;
			long cpf;
			double valorTransferencia = 0;
			verTodasContas();
			System.out.print("Informe de qual agencia deseja transferir:");
			agenciaConta = sc.nextInt();
			System.out.print("Informe de qual numero da conta deseja transferir:");
			numeroConta = sc.nextInt();
			ContaCorrente contaCorrenteCliente = validarContaCorrente(agenciaConta, numeroConta);
			if (contaCorrenteCliente == null) {
				System.out.println("Conta ou agencia não encontrados.");
				System.out.println("Não é possivel trasnferir.");
			} else {
				System.out.print("Informe o valor que deseja transferir: ");
				valorTransferencia = sc.nextDouble();
				if (valorTransferencia > contaCorrenteCliente.getSaldoConta() && valorTransferencia > 0) {
					System.out.println("Saldo indisponivel para transferencia");
					System.out.println("Saldo disponivel: " + contaCorrenteCliente.getSaldoConta());
				} else {
					System.out.print("Informe a agencia que deseja transferir:");
					agenciaConta = sc.nextInt();
					System.out.print("Informe o numero da conta que deseja transferir:");
					numeroConta = sc.nextInt();
					System.out.print("Informe o nome do cliente que deseja transferir:");
					sc.nextLine();// fica em observação se vai dar erro
					nomeCliente = sc.nextLine();
					System.out.print("Informe o numero do cpf que deseja transferir:");
					cpf = sc.nextLong();
					ContaCorrente contaCorrenteDestinatario = validarTransferencia(agenciaConta, numeroConta,
							nomeCliente, cpf);

					if (contaCorrenteDestinatario == null) {
						System.out.println("Usuário que deseja tranferir não foi encotrado");
					} else {
						contaCorrenteDestinatario
								.setSaldoConta(contaCorrenteDestinatario.getSaldoConta() + valorTransferencia);
						contaCorrenteCliente.setSaldoConta(contaCorrenteCliente.getSaldoConta() - valorTransferencia);
						System.out.println("Valor trasnferido com sucesso");
						System.out.print("Saldo atual: " + contaCorrenteCliente.getSaldoConta());
					}
				}
			}
		}
	}

	public void payBill() {
		Scanner sc = new Scanner(System.in);
		ContaCorrente contaCorrente = viewAccount();
		if (contaCorrente == null) {
			System.out.println("Conta não existe");
		} else {
			int agenciaConta = 0;
			int numeroConta = 0;
			double valorPagamento = 0;
			System.out.print("Informe sua agencia:");
			agenciaConta = sc.nextInt();
			System.out.print("Informe sua conta:");
			numeroConta = sc.nextInt();
			ContaCorrente contaCorrenteCliente = validarContaCorrente(agenciaConta, numeroConta);
			if (contaCorrenteCliente == null) {
				System.out.println("Conta ou agencia não encontrados");
			} else {
				System.out.print("Digite o valor de pagamento:");
				valorPagamento = sc.nextDouble();
				if (valorPagamento > contaCorrenteCliente.getSaldoConta() && valorPagamento < 0) {
					System.out.println("Não há saldo disponivel para pagamento");
				} else {
					contaCorrenteCliente.setSaldoConta(contaCorrenteCliente.getSaldoConta() - valorPagamento);
					System.out.println("Foi pago:" + valorPagamento);
					System.out.println("Seu saldo atual: " + contaCorrenteCliente.getSaldoConta());
					System.out.println("");
				}
			}

		}
	}

	public void deposit() {
		ContaCorrente contaCorrente = viewAccount();
		if (contaCorrente == null) {
			System.out.println("Conta não existe");
		} else {
			Scanner sc = new Scanner(System.in);
			int agenciaConta = 0;
			int numeroConta = 0;
			double valorDeposito = 0;
			verTodasContas();
			System.out.print("Informe sua agencia:");
			agenciaConta = sc.nextInt();
			System.out.print("Informe sua conta:");
			numeroConta = sc.nextInt();
			ContaCorrente contaCorrenteCliente = validarContaCorrente(agenciaConta, numeroConta);
			if (contaCorrenteCliente == null) {
				System.out.println("Conta ou agencia não encontrados");
			} else {
				System.out.print("Digite o valor que deseja depositar:");
				valorDeposito = sc.nextDouble();
				if (valorDeposito < 0) {
					System.out.println("Valor para deposito é invalido");
				} else {
					System.out.print("Informe de qual agencia deseja transferir:");
					agenciaConta = sc.nextInt();
					System.out.print("Informe de qual numero da conta deseja transferir:");
					numeroConta = sc.nextInt();
					ContaCorrente contaCorrenteDestinatario = validarDeposito(agenciaConta, numeroConta);
					if (contaCorrenteDestinatario == null) {
						System.out.println("Usuario não encontrado não é possivel fazer o deposito");
					} else {
						contaCorrenteDestinatario.setSaldoConta(contaCorrenteDestinatario.getSaldoConta() + valorDeposito);
						System.out.println("Valor depositado com sucesso");
						System.out.print("Saldo atual: " + contaCorrenteDestinatario.getSaldoConta());
					}
				}
			}
		}
	}

	public ContaCorrente validarDeposito(int agenciaConta, int numeroConta) {
		for (Client cliente : Banco.listaCliente) {
			for (ContaCorrente contaClient : cliente.listaContasBancarias) {
				if (contaClient.getNumeroConta() == numeroConta && contaClient.getAgenciaConta() == agenciaConta)
					return contaClient;
			}
		}
		return null;
	}

	public ContaCorrente validarTransferencia(int agenciaConta, int numeroConta, String nomeCliente, long cpf) {
		for (Client cliente : Banco.listaCliente) {
			for (ContaCorrente contaClient : cliente.listaContasBancarias) {
				if (contaClient.getNumeroConta() == numeroConta && contaClient.getAgenciaConta() == agenciaConta
						&& cliente.getNome().equals(nomeCliente) && cliente.getCpf() == cpf)
					return contaClient;
			}
		}
		return null;
	}

	// função valida se a conta corrente existe
	public ContaCorrente validarContaCorrente(int agencia, int numero) {
		for (ContaCorrente c : this.listaContasBancarias) {
			if (c.getNumeroConta() == numero && c.getAgenciaConta() == agencia) {
				return c;
			}
		}
		// retorna nulo caso não encontre agencia ou num_conta
		return null;
	}

	public void verTodasContas() {
		int verifica = 0;
		for (ContaCorrente c : listaContasBancarias) {
			c.mostrarContaSemSaldo();
			verifica = 1;
		}
		if (verifica == 0) {
			System.out.println("Não ha contas");
		}
	}

	// vizualizar informações da conta
	public ContaCorrente viewAccount() {
		for (ContaCorrente c : listaContasBancarias) {
			//c.mostrarContaSemSaldo();
			return c;
		}
		return null;
	}

	public void closeAccount() {
		if (this.listaContasBancarias.size() == 0) {
			System.out.println("Conta não existe");
		} else {
			Scanner sc = new Scanner(System.in);
			int rmvAgenciaConta = 0;
			int rmvNumeroConta = 0;
			verTodasContas();
			System.out.print("Informe a agencia:");
			rmvAgenciaConta = sc.nextInt();
			System.out.print("Informe o numero da conta:");
			rmvNumeroConta = sc.nextInt();
			ContaCorrente contaCorrente = validarContaCorrente(rmvAgenciaConta, rmvNumeroConta);
			if (contaCorrente == null) {
				System.out.println("Conta não encotrada");
			} else {
				System.out.println("A seguinte conta será removida:");
				contaCorrente.mostrarContaComSenha();
			}
			removerConta(rmvAgenciaConta, rmvNumeroConta);
		}
	}

	public ContaCorrente removerConta(int agencia, int numero) {
		for (ContaCorrente c : listaContasBancarias) {
			if (c.getNumeroConta() == numero && c.getAgenciaConta() == agencia) {
				listaContasBancarias.remove(c);
				System.out.println("O cliente foi removido com sucesso");
				return c;
			}
		}
		System.out.println("Conta ou agencia não encontrados");
		return null;
	}
}